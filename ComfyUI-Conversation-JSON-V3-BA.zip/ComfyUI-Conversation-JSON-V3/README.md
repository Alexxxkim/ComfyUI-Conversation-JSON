# Conversation JSON V3 · 可选风格

独立的 ComfyUI Custom Node。只注册 `DMCanvasConversationJSONV3`，不注册或替换 V2；可以与 V2 并排安装，已有工作流不用迁移。包内的 `_v2.py` 和 `conversation.py` 原样取自 2026-11-14 的 V2 发布包（前者原名 `nodes.py`），无需另外安装 V2 或 Python 依赖。

## 安装到 BA（ByteArtist）

- 可管理 `custom_nodes` 目录时：解压安装包，把 `ComfyUI-Conversation-JSON-V3` 文件夹放进 `ComfyUI/custom_nodes/`，与旧插件并列；不要覆盖 V2，也不要多套一层目录。
- 若房间只提供 Git 仓库安装：将本目录的**内容**放到 BA 可访问的仓库根目录（根层应有 `__init__.py`、`nodes.py`、`_v2.py`、`conversation.py`、`web/`），在 BA 的 Custom Node 安装入口填写该仓库和对应分支或提交。不是把 ZIP 或工作流 JSON 当作仓库地址。
- 重新加载房间后端，再刷新画布；在 `DM Canvas/Conversation` 中搜索 `Conversation JSON V3`。可拖入 `examples/style_v3.workflow.json` 试用，也可以在现有工作流里手动添加 V3。

## 接线与输出

左侧按顺序为 `conversation`（必填）、`region`、`style_name`、`style_prompt`，都是可从 Text / String 节点接入的 `STRING` 口。`input_format` 和 `case_index` 仍是节点内控件。四路输出仍是 `json`、`image_order`、`warnings`、`case_count`，顺序不变。

| 风格名称 `style_name` | 规则 `style_prompt` | `json` 输出 |
| --- | --- | --- |
| 未接、空串或纯空白 | 任意，包括已接入的规则 | 不输出 `style`；全部四路输出与 V2 逐字相同 |
| `3D Emoji` | `圆润的 3D 造型，使用柔和高光。` | 新增顶层 `"style": {"name": "3D Emoji", "prompt": "圆润的 3D 造型，使用柔和高光。"}` |
| `3D Emoji` | 未接、空串或纯空白 | 新增顶层 `"style": {"name": "3D Emoji", "prompt": ""}` |

示例工作流预接了四个口；运行后可清空名称再运行，对比有无 `style` 的结果。风格名称会去除两端空白，非空规则中的引号、缩进及换行原样作为字符串保留。风格不会写进 `current_request.text` 或 `history`，也不会影响图片排序。

节点只组装 JSON，不渲染图片。下游需要应用风格时，建议明确约定：「先满足 `current_request`；若有 `style`，按 `style.prompt` 调整视觉表现，不改变用户指定的主体、动作或文字。冲突时以用户请求为准。」
